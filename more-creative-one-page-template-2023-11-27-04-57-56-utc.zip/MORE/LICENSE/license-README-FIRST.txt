---------------------------------------------
PIXEDEN // Resource license terms
---------------------------------------------
All our resources are royalty free for use in both personal and commercial projects.

You can modify any resources to your liking to fit into your project, we are however not legally liable for any misuse of our resources.

We do not ask for you to include any attribution or link back to Pixeden.com, we do however appreciate if you do credit our resources or/and help spread the word about us.

You cannot however redistribute, resell, lease, license, sub-license or offer our resources to any third party. This includes uploading our resources to another website, marketplace or media-sharing tool, and offering our resources as a separate attachment from any of your work. If you do plan to include one of our resource on an item or template that will be sold on a website or marketplace, we ask of you to contact us to determine the proper use of our resource before doing so. 

Premium files downloaded with a premium account can be used in a item or website template sold through a marketplace or directly on a website with no attribution required. You cannot however resell or redistribute those premium files as is. Please contact us before using those files in this way to ensure that you abide by our license. IMPORTANT you cannot use any resources from the psd web templates category to create a website theme or template to be sold. They can only be used for personal and commercial projects. 

If you would like to share one of our resource you can do so making a link to the specific resource page on Pixeden.com or/and use our preview images. No HOTLINKING is allowed i.e. you cannot make a direct link to the download or/and the images hosted on Pixeden.com.

---------------------------------------------
Find more great resources @ Pixeden.com
Sincerely,
The Pixeden Team.
---------------------------------------------
http://www.pixeden.com
PS. Those terms might change as we update our license on our website, please be sure to check the latest license terms on our website to avoid any misuse of our resources.
Thank you. 